new WOW().init();


lightGallery(document.getElementById('lightgallery'));